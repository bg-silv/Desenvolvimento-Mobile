package com.example.hamburgueriaz;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nomeCliente;
    private CheckBox adicionalBacon;
    private CheckBox adicionalQueijo;
    private CheckBox adicionalOnionRings;
    private TextView quantidadeTextView;
    private int quantidade = 0;
    private EditText resumoPedidoTextView;
    private Button botaoSomar;
    private Button botaoSubtrair;
    private Button botaoEnviarPedido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Mapeando os IDs dos componentes
        nomeCliente = findViewById(R.id.editTextText);
        adicionalBacon = findViewById(R.id.checkBox);
        adicionalQueijo = findViewById(R.id.checkBox2);
        adicionalOnionRings = findViewById(R.id.checkBox3);
        quantidadeTextView = findViewById(R.id.textView8);
        resumoPedidoTextView = findViewById(R.id.editTextNumber);
        botaoSomar = findViewById(R.id.button2);
        botaoSubtrair = findViewById(R.id.button);
        botaoEnviarPedido = findViewById(R.id.button3);

        botaoSomar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantidade++;
                atualizarQuantidade();
            }
        });

        botaoSubtrair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quantidade > 0) {
                    quantidade--;
                    atualizarQuantidade();
                }
            }
        });

        botaoEnviarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarPedido();
            }
        });
    }

    private void atualizarQuantidade() {
        quantidadeTextView.setText(String.valueOf(quantidade));
    }

    private void enviarPedido() {
        String nome = nomeCliente.getText().toString();
        boolean hasBacon = adicionalBacon.isChecked();
        boolean hasQueijo = adicionalQueijo.isChecked();
        boolean hasOnionRings = adicionalOnionRings.isChecked();

        String resumoPedido = "Nome: " + nome + "\n" +
                "Bacon: " + (hasBacon ? "Sim" : "Não") + "\n" +
                "Queijo: " + (hasQueijo ? "Sim" : "Não") + "\n" +
                "Onion Rings: " + (hasOnionRings ? "Sim" : "Não") + "\n" +
                "Quantidade: " + quantidade;

        resumoPedidoTextView.setText(resumoPedido);

        // Simulando envio do pedido
        Toast.makeText(this, "Pedido enviado!\n" + resumoPedido, Toast.LENGTH_LONG).show();
    }
}
